export interface IAppendAvatarInterface {
  avatar: string;
  number: number;
}
