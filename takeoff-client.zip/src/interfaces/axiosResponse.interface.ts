export interface IErrorResponse {
  message: string;
}
