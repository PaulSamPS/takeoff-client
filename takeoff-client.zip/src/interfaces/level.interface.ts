export interface ILevelInterface {
  id: number;
  name: string;
}
