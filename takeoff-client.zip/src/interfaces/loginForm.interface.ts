export interface ILoginForm {
  name: string;
  password: string;
}
