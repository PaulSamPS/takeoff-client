export interface IPositionInterface {
  id: number;
  name: string;
}
