export interface IRefreshToken {
  accessToken: string;
}
