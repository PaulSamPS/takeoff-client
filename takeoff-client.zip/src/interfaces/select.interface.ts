export interface ISelectOption {
  value: string;
  label: string;
}
