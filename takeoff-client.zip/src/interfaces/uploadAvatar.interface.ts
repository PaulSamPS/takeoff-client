export interface IUploadAvatar {
  avatar: string;
}
