declare module '*.module.scss';
declare module '*.svg';
declare module '*@';
